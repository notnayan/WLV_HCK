let weather = {
    apiKey: "5c559d1fb8c4001fd5645102c8aac370",
    fetchWeather: function (city) {
      fetch(
        "https://api.openweathermap.org/data/2.5/weather?q=" +
          city +
          "&units=metric&appid=" +
          this.apiKey
      )
        .then((response) => {
          if (!response.ok) {
            alert("No weather found.");
            throw new Error("No weather found.");
          }
          return response.json();
        })
        .then((data) => this.displayWeather(data));
    },
    displayWeather: function (data) {
      const { name } = data;
      const { icon, description } = data.weather[0];
      const { temp, humidity } = data.main;
      const { speed } = data.wind;
      const { deg } = data.wind;
      const { pressure } = data.main; 
      
      date = new Date(data.dt * 1000);
      document.querySelector(".city").innerText = name;
      document.querySelector(".icon").src ="https://openweathermap.org/img/wn/" + icon + ".png";
      document.querySelector(".description").innerText = description;
      document.querySelector(".temp").innerText = Math.round(temp) + "°C";
      document.querySelector(".humidity").innerText =
        "Humidity: " + humidity + "%";
      document.querySelector(".wind").innerText =
        "Wind speed: " + speed + " m/s";
      document.querySelector(".winddeg").innerText =
        "Wind Degree: " + deg + "°";
      document.querySelector(".pressure").innerText =
        "Pressure: " + pressure + " hPa";
      document.querySelector(".date").innerText = date.toDateString();
    },
    
  };
  
  weather.fetchWeather("Gloucestershire");