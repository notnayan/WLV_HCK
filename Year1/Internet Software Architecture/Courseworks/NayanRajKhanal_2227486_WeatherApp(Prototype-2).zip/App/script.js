let weather = {
    fetchWeather: function (city) {
      fetch(`http://localhost/NayanRajKhanal_2227486_WeatherApp/app/index.php?City=${city}`
      )
        .then((response) => {
          if (!response.ok) {
            alert("No weather found.");
            throw new Error("No weather found.");
          }
          return response.json();
        })
        .then((data) => this.displayWeather(data));
    },
    displayWeather: function (data) {
      const { City } = data;
    const { Icon,Weather_description } = data;
    const { Weather_temperature, Pressure, Humidity} = data;
    const { Weather_wind, Direction_of_wind } = data;
    date = new Date(data.dt * 1000);

      document.querySelector(".city").innerText = City;
      document.querySelector(".icon").src ="https://openweathermap.org/img/wn/" + Icon + ".png";
      document.querySelector(".description").innerText = Weather_description;
      document.querySelector(".temp").innerText = Math.round(Weather_temperature) + "°C";
      document.querySelector(".humidity").innerText =
        "Humidity: " + Humidity + "%";
      document.querySelector(".wind").innerText =
        "Wind speed: " + Weather_wind + " m/s";
      document.querySelector(".winddeg").innerText =
        "Wind Degree: " + Direction_of_wind + "°";
      document.querySelector(".pressure").innerText =
        "Pressure: " + Pressure + " hPa";
      document.querySelector(".date").innerText = date.toDateString();
    },
    
  };
  
  weather.fetchWeather("Gloucestershire");