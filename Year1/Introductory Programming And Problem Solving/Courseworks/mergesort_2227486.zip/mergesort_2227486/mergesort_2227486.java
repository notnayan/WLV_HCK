import java.util.ArrayList;
import java.util.Scanner;

public class mergesort_2227486
{

    void getInput(ArrayList<Integer> array)
    {
        Scanner scanner = new Scanner(System.in);
        System.out.print("What is the maximum amount of numbers you wish to enter: ");
        int num = scanner.nextInt();
        for (int i = 0; i < num; i++)
        {
            System.out.printf("Enter your number: ");
            array.add(scanner.nextInt());
        }
        scanner.close();
    }

    void getOutput(ArrayList<Integer> array) {
        System.out.println("Your final Sorted Array is: ");
        for (int i = 0; i < array.size(); i++)
        {
            System.out.print(array.get(i) + " ");
        }
        System.out.print("\n");
    }

    void merge(ArrayList<Integer> array, int start, int mid, int end)
    {

        int x = start;
        int y = mid + 1;
        int z = start;
        ArrayList<Integer> temp = new ArrayList<Integer>();
        while (x <= mid && y <= end)
        {

            if (array.get(x) < array.get(y))
            {
                temp.add(array.get(x));
                x++;
            }

            else
            {
                temp.add(array.get(x));
                x++;
            }
        }
        while (x <= mid)
        {
            temp.add(array.get(x));
            x++;
        }

        while (y <= end)
        {
            temp.add(array.get(y));
            y++;
        }

        for (int l = 0; l < temp.size(); l++)
        {
            array.set(z, temp.get(l));
            z++;
        }

    }

    void sort(ArrayList<Integer> array, int start, int end)
    {
        if (start < end) {
            int mid = (start + end) / 2;
            sort(array, start, mid);
            sort(array, mid + 1, end);
            merge(array, start, mid, end);
        }
    }

    public static void main(String[] args)
    {
        mergesort_2227486 mergeSort = new mergesort_2227486();
        ArrayList<Integer> array = new ArrayList<Integer>();
        mergeSort.getInput(array);
        mergeSort.sort(array, 0, array.size() - 1);
        mergeSort.getOutput(array);
    }
}



