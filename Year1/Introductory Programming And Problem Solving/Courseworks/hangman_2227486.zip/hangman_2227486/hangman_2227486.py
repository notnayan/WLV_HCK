# Coding Challenge 3, hangman.py
# Name: Nayan Raj Khanal
# Student No: 2227486

# Hangman Game

# -----------------------------------
# Helper code
# You don't need to understand this helper code,
# but you will have to know how to use the functions
# (so be sure to read the docstrings!)

import random
import os

WORDLIST_FILENAME = "words.txt"

# Responses to in-game events
# Use the format function to fill in the spaces
responses = [
    "I am thinking of a word that is {0} letters long",
    "Congratulations, you won!",
    "Your total score for this game is: {0}",
    "Sorry, you ran out of guesses. The word was: {0}",
    "You have {0} guesses left.",
    "Available letters: {0}",
    "Good guess: {0}",
    "Oops! That letter is not in my word: {0}",
    "Oops! You've already guessed that letter: {0}",
]


def choose_random_word(all_words):
    """
    Chooses a random word from those available in the wordlist

    Args:
        all_words (list): list of available words (strings)

    Returns:
        a word from the wordlist at random
    """
    while True:
        random.choice(all_words)

    # Returns a new word each time the game is re-run
        if random.choice(all_words) in already_used:
            continue
        else:
            # Randomly returns a word from wordlist
            return random.choice(all_words)

# Load the list of words into the variable wordlist
# Accessible from anywhere in the program
# you have implemented the load_words() function


text = []
guessed_list = []
game_rounds = [0]
already_used = []


def load_words():
    """
    Generate a list of valid words. Words are strings of lowercase letters.

    Returns:
        A list of valid words.
    """

    # If the word file does not exist, an error is displayed
    if not os.path.isfile(WORDLIST_FILENAME):
        print('''
Error: Word file does not exist in the directory.
        ''')
        exit()

    else:
        # Opening the word file in read mode
        file = open(WORDLIST_FILENAME, "r")

        # Adding words to a list by splitting them up
        all_words = file.read().split()
        file.close()

        # Returns the list with words of the word file
        return all_words


def is_word_guessed(word, letters_guessed):
    """
    Determine whether the word has been guessed

    Args:
        word (str): the word the user is guessing
        letters_guessed (list): the letters guessed so far

    Returns:
        boolean, True if all the letters of word are in letters_guessed; False otherwise
    """

    # Make a list of all the letters the user successfully predicted
    if letters_guessed in word:
        guessed_list.append(letters_guessed)
        get_remaining_letters(guessed_list)
        return True
    else:
        guessed_list.append(letters_guessed)
        get_remaining_letters(guessed_list)
        return False


def get_guessed_word(word, letters_guessed):
    """
    Determines the current guessed word, with underscores

    Args:
        word (str): the word the user is guessing
        letters_guessed (list): which letters have been guessed so far

    Returns:
        string, comprised of letters, underscores (_), and spaces that represents which letters have been guessed so far.
    """
    # Check the letters guessed with the word and replace unknown letters with an underscore

    # If no letters are predicted by the user, use underscores
    if len(text) == 0:
        for letter in word:
            if letters_guessed == letter:
                text.append(letters_guessed)
            else:
                text.append("_")
    # Else if user has guessed more than a letter
    else:
        i = 0
        for letter in word:
            if letters_guessed == letter:
                text[i] = letter
            i += 1

    return text


def get_remaining_letters(letters_guessed):
    """
    Determine the letters that have not been guessed

    Args:
        letters_guessed: list (of strings), which letters have been guessed

    Returns:
        String, comprised of letters that haven't been guessed yet.
    """
    # Remove the letters that the user guessed and replace them with the remaining letters
    from string import ascii_lowercase
    all_letters = ascii_lowercase
    for letter in letters_guessed:
        all_letters = all_letters.replace(letter, "")
    return all_letters


def get_score():

    score_set = {}

    # Reading each line from the score text file
    file = open("Scores.txt", "r")
    for lines in file:
        ln = lines.strip("\n").split("    ")
        score = ln[0]
        name = ln[1]
        score_set.update({name: score})
    return score_set


def save_score(name, score):

    score_list = []
    update = False

    # Checking if the file exists
    if os.path.isfile("Scores.txt"):

        # Checking if the content of the file is empty
        if os.stat("Scores.txt").st_size == 0:
            score_list.append(str(score)+"     "+name)

        # If file is not empty
        else:
            with open("Scores.txt", "r") as file:
                lines = file.readlines()

                for line in lines:
                    strip = line.strip("\n")
                    split = strip.split("     ")
                    if split[1].lower() == name.lower():
                        update = True

                        # Checking if user scored a highscore
                        if int(split[0]) < score:
                            while True:
                                input = str(
                                    input("Congratulations! New Record! Will you overwrite your score?(y/n)").lower())
                                if input == "y" or input == "n":
                                    if input == "y":
                                        score_list.append(
                                            str(score)+"     "+name)
                                        break
                                    else:
                                        score_list.append(strip)
                                        break
                                else:
                                    print("Invalid Input!")
                    else:
                        score_list.append(strip)

                if not update:
                    score_list.append(str(score)+"     "+name)

    # If the file does not already exist, create a new one and append the scores to it
    else:
        with open("Scores.txt", "w") as score_file:
            score_list.append(str(score)+"     "+name)

    # If the user has an existing score, replace it with the new one.
    with open("Scores.txt", "w") as score_file:
        for lines in score_list:
            score_file.write(lines+"\n")


wordlist = load_words()

# Printing intro message
print("Loading word list from file..")
print(len(wordlist))
print("Welcome to Hangman Ultimate Edition")
print(" ")


def divider():
    print("-" * 30)


def hangman(word):
    """
    Runs an interactive game of Hangman.
    Args:
        word: string, the word to guess.
    """

    game_end = False

    # Maximum tries available to the user
    no_of_attempts = 6

    # Main memu
    while True:
        choice = str(
            input("(P) Play the game \n(L) View the leaderboard \n(Q) Quit:").lower())

        if choice != "p" and choice != "l" and choice != "q":
            print("Error: Please enter a valid choice!")
        else:
            break

    # Run the game if user selects play
    if choice == "p":
        divider()
        while True:
            name = str(input("Please enter your name: ").lower())
            if name == " " or name == "":
                print("Error: Please enter a valid name!")
            else:
                break
        print(responses[0].format(len(word)))
        divider()
        # Instruct the user to type a letter until the total number of attempts is exhausted
        while not game_end:

            print(responses[4].format(no_of_attempts))
            print(responses[5].format(get_remaining_letters(guessed_list)))

            # Request that the user guess a word's letter
            while True:
                guessed_letter = str(input("What is your guess? :").lower())
                if len(guessed_letter) > 1 or guessed_letter == " " or guessed_letter == "":
                    print("Error: Please enter a valid guess!")
                else:
                    break

            # If the user guesses a letter that hasn't been guessed before
            if guessed_letter not in guessed_list:
                if is_word_guessed(word, guessed_letter) == True:
                    get_guessed_word(word, guessed_letter)
                    print(responses[6].format(" ".join(text)))
                    divider()

                    # Show a congratulation message if user guessed the word
                    if "".join(text) == word:

                        print(responses[1])
                        score = len(set(word))*no_of_attempts

                        print(responses[2].format(score))
                        already_used.append(word)
                        game_end = True

                        # Resetting the global variable for another round
                        game_rounds[0] += 1
                        if game_rounds[0] > 0:
                            text.clear()
                            guessed_list.clear()

                    # Using a score text file to save the user's score
                        loop = True
                        while loop:
                            save_s = str(
                                input("Do you want to keep track of your score?(y/n):").lower())
                            if save_s != "y" and save_s != "n":
                                print("Error: Please enter a valid choice!")
                            else:
                                if save_s == "y":
                                    save_score(name, score)
                                    divider()

                                # Asking if the user wants to start another round of the game
                                while True:
                                    choice = str(
                                        input("Would you like to play again?(y/n)").lower())
                                    if choice != "y" and choice != "n":
                                        print("Error: Please enter a valid choice!")
                                    else:
                                        if choice == "y":
                                            word = choose_random_word(wordlist)
                                            hangman(word)
                                        else:
                                            print(
                                                "Thank you for playing, Hope you had fun!")
                                            loop = False
                                            exit()
                                        break

                # If the word does not contain the letter that the user predicted
                else:
                    if not text:

                        print(responses[7].format(" ".join("_" * len(word))))
                        divider()

                    else:

                        print(responses[7].format(" ".join(text)))
                        divider()
                        no_of_attempts -= 1

            # If user enters a letter that has already been already guessed
            else:

                print(responses[8].format(" ".join(text)))
                divider()

            # If the user has exhausted their attempts
            if no_of_attempts <= 0:
                already_used.append(word)

                print(responses[3].format(word))
                game_end = True
                game_rounds[0] += 1
                if game_rounds[0] > 0:
                    text.clear()
                    guessed_list.clear()

                # Asking if the user wants to start another round of the game
                while True:
                    choice = str(
                        input("Would you like to play another game?(y/n)").lower())
                    if choice != "y" and choice != "n":
                        print("Error: Please enter a valid choice!")
                    else:
                        if choice == "y":
                            word = choose_random_word(wordlist)
                            hangman(word)
                        else:
                            print("Thank you for playing, Hope you had fun!")
                            exit()
                    break

    # Display the leaderboard if user inputs 'l' in the menu
    elif choice == "l":

        # Checking if the file exists
        if os.path.isfile("Scores.txt"):
            score = get_score()

            # Checking if the content of the score file is empty
            if len(score) == 0:
                print("   " + "Leaderboard is empty. Win a game and earn your spot!")

                while True:
                    choice = str(
                        input("Would you like to play another game?(y/n)").lower())
                    if choice != "y" and choice != "n":
                        print("Error: Please enter a valid choice!")
                    else:
                        if choice == "y":
                            word = choose_random_word(wordlist)
                            hangman(word)
                        else:
                            print("Thank you for playing, Hope you had fun!")
                            exit()
                        break

            # If the content of the score.txt is not empty
            else:
                score = get_score()
                # Sorting the scores list in descending order
                score = sorted(score.items(), key=lambda s: s[1], reverse=True)
                print("{:<15}{:<15}".format("Score", "Names"))
                divider()
                for i in range(0, len(score)):
                    print("{:<15}{:<15}".format(score[i][1], score[i][0]))
                divider()

                # Asking the user if they want to play another or exit
                while True:
                    choice = str(
                        input("Would you like to play another game?(y/n)").lower())
                    if choice != "y" and choice != "n":
                        print("Error: Please enter a valid choice!")
                    else:
                        if choice == "y":
                            word = choose_random_word(wordlist)
                            hangman(word)
                        else:
                            print("Thank you for playing, Hope you had fun!")
                            exit()
                        break

    # If the user selects to quit the game
    else:
        print("Thank you for playing, Hope you had fun!")
        exit()


# When you've completed your hangman function, scroll down to the bottom
# of the file and uncomment the last lines to test
# (hint: you might want to pick your own
# word while you're doing your own testing)
# -----------------------------------
# Driver function for the program
if __name__ == "__main__":
    word = choose_random_word(wordlist)
    hangman(word)
