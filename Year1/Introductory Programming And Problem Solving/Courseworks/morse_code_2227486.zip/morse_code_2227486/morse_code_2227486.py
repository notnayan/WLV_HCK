# Coding Challenge 2
# Name: Nayan Raj Khanal
# Student No: 2227486

# A Morse code encoder/decoder

MORSE_CODE = (
    ("-...", "B"), (".-", "A"), ("-.-.", "C"), ("-..",
                                                "D"), (".", "E"), ("..-.", "F"), ("--.", "G"),
    ("....", "H"), ("..", "I"), (".---", "J"), ("-.-",
                                                "K"), (".-..", "L"), ("--", "M"), ("-.", "N"),
    ("---", "O"), (".--.", "P"), ("--.-", "Q"), (".-.",
                                                 "R"), ("...", "S"), ("-", "T"), ("..-", "U"),
    ("...-", "V"), (".--", "W"), ("-..-", "X"), ("-.--",
                                                 "Y"), ("--..", "Z"), (".-.-.-", "."),
    ("-----", "0"), (".----", "1"), ("..---",
                                     "2"), ("...--", "3"), ("....-", "4"), (".....", "5"),
    ("-....", "6"), ("--...", "7"), ("---..",
                                     "8"), ("----.", "9"), ("-.--.", "("), ("-.--.-", ")"),
    (".-...", "&"), ("---...", ":"), ("-.-.-.",
                                      ";"), ("-...-", "="), (".-.-.", "+"), ("-....-", "-"),
    ("..--.-", "_"), (".-..-.", '"'), ("...-..-",
                                       "$"), (".--.-.", "@"), ("..--..", "?"), ("-.-.--", "!")
)

# The welcome message is being printed
def print_intro():
    print('Welcome to Wolmorse')
    print('This program encodes and decodes Morse code.')


# Function that prompts the user for encoding or decoding of the message or file
def get_filename_input():
    message = "None"
    filename = "None"

    # Inquire if the user wants to encrypt or decode a message
    while (True):
        try:
            decision = input(
                'Would you like to encode (e) or decode (d)?: ').lower()
            if decision not in ['e', 'd']:
                print('Error: Invalid Mode')
                continue
            break
        except ValueError:
            print('Error: Invalid Mode')
            continue

    # Inquire if the user wants to enter a message or a file
    while (True):
        try:
            method = input(
                'Would you like to read from a file (f) or the console (c)?: ').lower()
            if method not in ['f', 'c']:
                print('Error: Invalid Mode')
                continue
            break
        except ValueError:
            print('Error: Invalid Mode')
            continue

    if method == 'f':

        # Request the filename from the user
        while(True):
            try:
                filename = input('Enter a filename: ')
                if not check_file_exists(filename):
                    print('Error: File not found')
                    continue
                break
            except FileNotFoundError:
                print('Error: File not found')
                continue

    else:
        if decision == 'e':

            # Request the message to be encoded from the user
            while (True):
                try:
                    message = input(
                        'What message would you like to encode?: ').upper()
                    break
                except ValueError:
                    print('Error: Invalid Message')
                    continue

        else:

            # Request the user's message to decode
            while (True):
                try:
                    message = input(
                        'What message would you like to decode? : ').upper()
                    break
                except ValueError:
                    print('Error: Invalid Message')
                    continue

    return decision, message, filename

# Message encoding function
def encode(message):
    morse_code = ''
    # Loop through the message
    for character in message:
        # Loop through the morse code dictionary
        for i in range(len(MORSE_CODE)):
            # If the word appears in the dictionary
            if character == MORSE_CODE[i][1]:
                # To the output, add the relevant morse code
                morse_code += MORSE_CODE[i][0] + " "
        if character == " ":
            morse_code += "   "
    return morse_code


# Message decoding function
def decode(message):
    normal_text = ''
    # Separate the morse code into distinct words
    words = message.split('   ')
    # Loop through the morse code words
    for word in words:
        # Divide the morse code words into morse code letters
        characters = word.split(' ')
        # Loop through the morse code characters
        for character in characters:
            # Loop through the morse code dictionary
            for i in range(len(MORSE_CODE)):
                # If the dictionary contains the morse code
                if character == MORSE_CODE[i][0]:
                    # To the output, add the relevant character
                    normal_text += MORSE_CODE[i][1]
        normal_text += " "
    return normal_text

# ---------- Challenge Functions (Optional) ----------

# Function that encodes or decodes the provided file
def process_lines(filename, mode):
    output = ""
    file = open(filename, 'r')
    if mode == 'e':
        # Encoding the file
        for line in file.readlines():
            for character in line:
                output += encode(character.upper())
            output += "\n"
        line = file.readlines()

    else:
        # Decoding the file
        for line in file.readlines():
            output += decode(line.upper()) + '\n'
            line = file.readlines()
    file.close()
    return output


# Function that writes the output to a file
def write_lines(lines):
    file = open('result.txt', "w")
    # Writing the given lines to the result file
    file.write(lines)
    file.close()
    print('Output written to result.txt')


# Function that checks if the specified file exists
def check_file_exists(filename):
    # If no exception is raised when opening the file, return true.
    try:
        input_file = open(filename, 'r')
        input_file.close()
        return True
    # Return false if an exception is raised
    except IOError:
        return False


"""
MAIN DRIVER FUNCTION
----------------------------------------------------------------------------------------------
Requirements:
    • Prompt users to select a mode: encode (e) or decode (d).
    • Check if the mode the user entered is valid.
    If not, continue to prompt the user until a valid mode is selected.
    • Prompt the user for the message they would like to encode/decode.
    • Encode/decode the message as appropriate and print the output.
    • Prompt the user whether they would like to encode/decode another message.
        • Check if the user has entered a valid input (y/n).
          If not, continue to prompt the user until they enter a valid response.
          Depending upon the response you should either:
            • End the program if the user selects no.
            • Proceed directly to step 2 if the user says yes.
    • Your program should be as close as possible to the example shown in the assessment specification.

Hints:
    • Use the tuple MORSE_CODE above to convert between plain text/Morse code
    • You can make use of str.split() to generate a list of Morse words and characters
      by using the spaces between words and characters as a separator.
    • You will also find str.join() useful for constructing a string from a list of strings.
    • You should use a loop to keep the programming running if the user says that would like to
      encode/decode another message after the first.
    • Your program should handle both uppercase and lowercase inputs. You can make use of str.upper()
      and str.lower() to convert a message to that case.
    • Check the assessment specification for code examples.
"""

# Main Funtion
def main():
    print_intro()
    while(True):
        # Get the user's input
        file_input = get_filename_input()
        # Organizing the input list into matching variables
        decision = file_input[0]
        message = file_input[1]
        filename = file_input[2]

        # If the user wants to encode/decode a message from the console
        if message != "None":
            if decision == 'e':
                # Print the encoded message
                encoded_message = encode(message)
                print(encoded_message)
            else:
                # Print the decoded message
                decoded_message = decode(message)
                print(decoded_message)
        # If the user wants to encode/decode a file
        else:
            lines = process_lines(filename, decision)
            # Call the write_lines function to write the output to a file
            write_lines(lines)

        while(True):
            try:
                # Ask the user if they would like to encode/decode another message
                decision = input(
                    'Would you like to encode/decode another message? (y/n):').lower()

                if decision not in ['y', 'n']:
                    print('Error: Invalid Input')
                    continue
                break
            except ValueError:
                print('Error: Invalid Input')
                continue
        # Loop back to the start if the user wants to encode/decode another message
        if decision == 'y':
            continue
        # End the program if the user doesn't want to encode/decode another message
        else:
            print('Thanks for using the program, goodbye!')
            break


# Program execution begins here
if __name__ == '__main__':
    main()
