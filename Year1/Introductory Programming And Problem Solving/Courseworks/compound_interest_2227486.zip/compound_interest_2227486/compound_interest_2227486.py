# Coding Challenge 2, compound_interest.py
# Name: Nayan Raj Khanal
# Student No: 2227486

# Compound Interest Calculator

"""
Requirements:
    You will develop a program to calculate compound interest.

    • Print a welcome message explaining the purpose of the program.
    • Prompt the user for the necessary inputs (see formulae and brief)
    • Convert input values to suitable data types.
    • Perform compound interest calculation using the forumlae provided.
    • Print the result to the terminal using appropriate formatting.

    • Your program should be as close as possible to the example shown in the assessment brief.

Constraints:
    • Ensure that the interest rate is entered as a percentage and not a decimal.
    • Ensure that all monetary values are formatted to two decimal places.

Hints:
    • Think about what data types are the most appropriate for each input value.
    • Order of operations will be important, make sure you use parenthesis.
    • Review lecture two for more information on string formatting.
    • Your programs output should be as close as possible to the example in the assessment brief.
"""


# TODO: Write your code here!

# Creating a function called Compound Interest that takes four arguments; principal_amount, interest, year, period.
def compound_interest(principal_amount, interest, year, period):
    return principal_amount * (1 + (interest / 100)) ** (year * period)


# Prints a welcome message for the users.
print("Welcome to the Wolving compound interest calculator!\nThis program calculates your potential returns when you "
      "invest with us!\n")

# These four lines take input from the user.
principal_rate = float(input("What is the total sum of your deposit? "))
interest = float(input("What is the interest rate of your deposit? "))
year = int(input("What is the total time period of your deposit? "))
period = int(input("What is the total number of times the interest is compounded per year? "))

# Prints the heading of the table.
print('''
            Year | Period | Old Balance | Interest | New Balance
    ---------------------------------------------------------------------
      ''')

# The actual compound interest calculator with nested loops and proper formatting.
principal_amount = principal_rate
duration = 1
for start1 in range(year):
    for start2 in range(period):
        interest_rate = principal_amount * (interest / 100 / 4)
        print("            ", start1 + 1, "  |  ", duration, " |   ", "£"'{:.2f}'.format(principal_amount), "|",
              "£"'{:.2f}'.format(interest_rate), "|    ",
              "£"'{:.2f}'.format(compound_interest(principal_amount, interest / 4, 1, 1)))
        principal_amount = principal_amount + interest_rate
        duration += 1

# Prints a blank space.
print(" ")

# Prints the final cumulative output of all the inputs provided by the user
print(
    f"£{principal_rate} invested at {interest}% for {year} years compounded {period} times per year is: £" "{:.2f}".format(
        principal_amount))
